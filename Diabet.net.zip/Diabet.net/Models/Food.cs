﻿namespace Diabet.net.Models
{
    public class Food
    {
        public string Name {get;set;}
        public string Mass { get; set; }
        public string Cal { get; set; } 
    }
}
